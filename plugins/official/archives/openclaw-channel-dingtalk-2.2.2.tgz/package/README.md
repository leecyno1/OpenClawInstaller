# openclaw-channel-dingtalk

DingTalk (钉钉) Stream bot channel plugin for [OpenClaw](https://openclaw.ai).

Connect your OpenClaw AI agent to DingTalk via the Stream API — supports private messages and group chats.

## Features

- 🔗 Stream API connection (no public webhook required)
- 💬 Private messages & group chat
- 📝 Markdown formatting
- 🃏 ActionCard interactive messages
- 🔁 Reliable delivery with OpenAPI fallback

## Installation

```bash
openclaw plugins install openclaw-channel-dingtalk
```

## Configuration

Add to your `openclaw.json`:

```json
{
  "channels": {
    "dingtalk": {
      "appKey": "YOUR_APP_KEY",
      "appSecret": "YOUR_APP_SECRET",
      "agentId": "YOUR_AGENT_ID",
      "dmPolicy": "open"
    }
  }
}
```

You can find these values in the [DingTalk Open Platform](https://open.dingtalk.com/) → Your App → Basic Info.

| Field | Description |
|-------|-------------|
| `appKey` | App Key (also used as `robotCode` for sending messages) |
| `appSecret` | App Secret |
| `agentId` | Agent ID of your DingTalk app |
| `dmPolicy` | `"open"` to allow all DMs, or `"allowFrom"` to restrict |

## Requirements

- OpenClaw >= 2.0.0
- Node.js >= 18.0.0
- A DingTalk enterprise app with Stream mode enabled

## License

MIT
